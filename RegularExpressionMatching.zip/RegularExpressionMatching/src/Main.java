//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Solution solution = new Solution();
        System.out.println(solution.match("aa", "a"));
        System.out.println(solution.match("aa", "a*"));
        System.out.println(solution.match("ab", ".*"));

    }
}

class Solution
{
    public boolean match(String x, String p)
    {
        int l = x.length();
        int r = p.length();
        boolean[][] dp = new boolean[l+1][r+1];

        dp [0][0] = true;

        for (int i = 1; i <= r; i++)
        {
            if(p.charAt(i-1) == '*')
            {
                dp [0][i] = dp[0][i-2];
            }
        }

        for (int i = 1; i <= l; i++)
        {
            for(int j = 1; j <= r; j++)
            {
                char hp = x.charAt(i-1);
                char pc = p.charAt(j-1);

                if(pc == '.' || hp == pc)
                {
                  dp [i][j] = dp[i-1][j-1];
                }
                else if (pc == '*') {
                    dp [i][j] = dp[i-1][j-2];

                    char cp = p.charAt(j - 2);
                    if (cp == '.' || cp == hp) {
                        dp[i][j] |= dp[i - 1][j];
                    }
                }
            }
        }


        return dp[l][r];
    }
}